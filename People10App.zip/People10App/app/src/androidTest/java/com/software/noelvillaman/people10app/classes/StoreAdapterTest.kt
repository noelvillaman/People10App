package com.software.noelvillaman.people10app.classes

import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class StoreAdapterTest {

    lateinit var adapter: StoreAdapter



//    @Before
//    fun setup(){
//        adapter = StoreAdapter()
//    }

    @Test
    fun getItemCount() {
    }

    @Test
    fun onBindViewHolder() {
    }

    @Test
    fun onCreateViewHolder() {
    }

    @Test
    fun openAgregarPasajeros() {
    }
}