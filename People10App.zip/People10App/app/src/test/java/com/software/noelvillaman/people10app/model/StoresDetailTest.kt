package com.software.noelvillaman.people10app.model

import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class StoresDetailTest {
    lateinit var testDetail : StoresDetail

    @Before
    fun settup(){
        testDetail = StoresDetail()
    }

    @Test
    fun getPhone() {
        testDetail.phone

    }

    @Test
    fun setPhone() {
    }

    @Test
    fun getAddress() {
    }

    @Test
    fun setAddress() {
    }

    @Test
    fun getCity() {
    }

    @Test
    fun setCity() {
    }

    @Test
    fun getState() {
    }

    @Test
    fun setState() {
    }

    @Test
    fun getZipcode() {
    }

    @Test
    fun setZipcode() {
    }

    @Test
    fun getName() {
    }

    @Test
    fun setName() {
    }

    @Test
    fun getStoreLogoURL() {
    }

    @Test
    fun setStoreLogoURL() {
    }
}