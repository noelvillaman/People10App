package com.software.noelvillaman.people10app.classes

class AppMotor {
    companion object{
        val SECONDS_TO_OPEN_NEXT = 3000
    }
}